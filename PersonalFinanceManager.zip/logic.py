from datetime import datetime

class Transaction:
    def __init__(self, amount, type_, category):
        self.amount = amount
        self.type = type_
        self.category = category
        self.date = datetime.now().strftime("%Y-%m-%d")

class BudgetManager:
    def __init__(self):
        self.budget = 0

    def set_budget(self, amount):
        self.budget = amount

    def check_overflow(self, total_expense):
        return total_expense > self.budget

class CategoryManager:
    def get_categories(self):
        return ["Food", "Travel", "Utilities", "Salary", "Savings", "Other"]
