from gui import GUIManager
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = GUIManager(root)
    root.mainloop()
