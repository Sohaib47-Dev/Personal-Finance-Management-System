import sqlite3

class DatabaseHandler:
    def __init__(self, db_name="finance.db"):
        self.conn = sqlite3.connect(db_name)
        self.create_table()

    def create_table(self):
        query = """CREATE TABLE IF NOT EXISTS transactions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        amount REAL,
                        type TEXT,
                        category TEXT,
                        date TEXT
                   )"""
        self.conn.execute(query)
        self.conn.commit()

    def insert_transaction(self, amount, type_, category, date):
        query = "INSERT INTO transactions (amount, type, category, date) VALUES (?, ?, ?, ?)"
        self.conn.execute(query, (amount, type_, category, date))
        self.conn.commit()

    def fetch_transactions(self):
        cursor = self.conn.execute("SELECT * FROM transactions")
        return cursor.fetchall()

    def delete_transaction(self, id):
        self.conn.execute("DELETE FROM transactions WHERE id=?", (id,))
        self.conn.commit()
