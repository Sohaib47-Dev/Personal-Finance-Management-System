import tkinter as tk
from tkinter import messagebox, ttk
from db import DatabaseHandler
from logic import Transaction, BudgetManager, CategoryManager

class GUIManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal Finance Manager")

        self.db = DatabaseHandler()
        self.budget_manager = BudgetManager()
        self.categories = CategoryManager().get_categories()

        self.build_interface()

    def build_interface(self):
        self.amount_var = tk.StringVar()
        self.type_var = tk.StringVar(value="Income")
        self.category_var = tk.StringVar(value=self.categories[0])

        tk.Label(self.root, text="Amount:").grid(row=0, column=0)
        tk.Entry(self.root, textvariable=self.amount_var).grid(row=0, column=1)

        tk.Label(self.root, text="Type:").grid(row=1, column=0)
        ttk.Combobox(self.root, textvariable=self.type_var, values=["Income", "Expense"]).grid(row=1, column=1)

        tk.Label(self.root, text="Category:").grid(row=2, column=0)
        ttk.Combobox(self.root, textvariable=self.category_var, values=self.categories).grid(row=2, column=1)

        tk.Button(self.root, text="Add Transaction", command=self.add_transaction).grid(row=3, column=0, columnspan=2)

        self.tree = ttk.Treeview(self.root, columns=("Amount", "Type", "Category", "Date"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
        self.tree.grid(row=4, column=0, columnspan=2)

        self.refresh_tree()

    def add_transaction(self):
        try:
            amount = float(self.amount_var.get())
            type_ = self.type_var.get()
            category = self.category_var.get()

            transaction = Transaction(amount, type_, category)
            self.db.insert_transaction(transaction.amount, transaction.type, transaction.category, transaction.date)
            messagebox.showinfo("Success", "Transaction added successfully!")
            self.refresh_tree()
        except ValueError:
            messagebox.showerror("Error", "Invalid amount")

    def refresh_tree(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for row in self.db.fetch_transactions():
            self.tree.insert("", "end", values=row[1:])
