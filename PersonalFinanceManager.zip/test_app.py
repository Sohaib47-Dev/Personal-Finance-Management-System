import unittest
from logic import BudgetManager
from db import DatabaseHandler
import os

class TestBudgetManager(unittest.TestCase):
    def test_budget_overflow(self):
        bm = BudgetManager()
        bm.set_budget(1000)
        self.assertFalse(bm.check_overflow(500))
        self.assertTrue(bm.check_overflow(1500))

class TestDatabaseHandler(unittest.TestCase):
    def setUp(self):
        self.db = DatabaseHandler(db_name="test.db")

    def tearDown(self):
        self.db.conn.close()
        os.remove("test.db")

    def test_insert_and_fetch(self):
        self.db.insert_transaction(100, "Income", "Salary", "2025-06-20")
        results = self.db.fetch_transactions()
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0][1], 100)

if __name__ == '__main__':
    unittest.main()
